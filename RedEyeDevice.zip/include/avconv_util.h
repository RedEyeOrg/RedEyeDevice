#ifndef _REDEYE_DEVICE_AVCONV_UTIL
#define _REDEYE_DEVICE_AVCONV_UTIL

#include <stdbool.h>

void avconv_record();
void avconv_stop();

#endif
