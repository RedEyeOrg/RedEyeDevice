#!/bin/sh
scp -r ../RedEyeDevice pi@192.168.1.192:~/.
